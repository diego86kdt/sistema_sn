<?php
require_once '../includes/auth.php';
require_once '../includes/header.php';
require_once '../includes/functions.php';
?>
<h3>Envio (demo)</h3>
<p>Funcionalidade de envio de arquivos ainda é demonstrativa nesta versão.</p>
<?php require_once '../includes/footer.php'; ?>