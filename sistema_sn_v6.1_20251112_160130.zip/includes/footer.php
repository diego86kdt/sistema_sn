</main>
<footer class="text-center py-3 border-top">© <?=date('Y')?> - Sistema SN</footer>
<script src="/assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>