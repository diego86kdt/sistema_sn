// main.js - interações básicas
document.addEventListener('DOMContentLoaded',function(){});
