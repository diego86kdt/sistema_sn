// theme.js - salva tema no localStorage
